<?php

namespace sacn;

class Exception extends \RuntimeException
{
}

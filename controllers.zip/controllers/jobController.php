<?php

namespace app\controllers;

use app\models\mainModel;

if (isset($_POST['modulo_Opcion'])) {
	require_once '../phpmailer/src/PHPMailer.php';
	require_once '../phpmailer/src/SMTP.php';
	require_once '../phpmailer/src/Exception.php';
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//delcaracion de funciones del controlador
class jobController extends mainModel
{
	//funcion para cargar los formularios 
	public function listar()
	{

		$consulta_datos = "select * from \"SYSTEM\".OBTENER_JOBS;";

		$datos = $this->ejecutarConsulta($consulta_datos);
		$datos = $datos->fetchAll();

		return $datos;
	}

	public function listarservicios()
	{

		$consulta_datos = "select * from \"SYSTEM\".OBTENER_SERVICE where id_trabajo =" . $_GET['cargagridservicio'] . ";";

		$datos = $this->ejecutarConsulta($consulta_datos);
		$datos = $datos->fetchAll();

		return $datos;
	}

	//funcion para cargar los formularios 
	public function Buscarusuario()
	{
		if ($_POST["idjob"] == "0") {
			$consulta_datos = "select count(*) from \"SYSTEM\".OBTENER_COMPANY where UPPER(nombre)=UPPER('" . $_POST["nombre"] . "');";
		} else {
			$consulta_datos = "select count(*) from \"SYSTEM\".OBTENER_COMPANY where UPPER(nombre)=UPPER('" . $_POST["nombre"] . "') and id_company not in ('" . $_POST["idCompany"] . "');";
		}


		$datos = $this->ContarRegistros($consulta_datos);

		return $datos;
	}

	//Funcion para guardar los datos del formulario
	public function guardar()
	{

		$datosform[] = array(
			'idjob' => $_POST["idjob"],
			'idCompany' => $_POST["cmb_company"],
			'fullname' => $this->limpiarCadena($_POST["fullname"]),
			'city' => $this->limpiarCadena($_POST["city"]),
			'codigozip' => $_POST["codigozip"],
			'direccion' => $this->limpiarCadena($_POST["direccion"]),
			'cmb_estado' => $_POST["cmb_estado"],
			'phone' => $this->limpiarCadena($_POST["phone"]),
			'telefono' => $this->limpiarCadena($_POST["telefono"]),
			'email' => $this->limpiarCadena($_POST["email"]),
			'companyname' => $this->limpiarCadena($_POST["companyname"]),
			'contactinfo' => $this->limpiarCadena($_POST["contactinfo"]),
			'contactphone' => $this->limpiarCadena($_POST["contactphone"]),
			'contactmail' => $this->limpiarCadena($_POST["contactmail"]),
			'nte' => $_POST["nte"],
			'fee' => $_POST["fee"],
		);

		$datos = json_encode($datosform);


		if ($_POST["idjob"] == "0") {
			$sentencia = "select \"SYSTEM\".INSERTAR_JOB('" . $datos . "','" . $_SESSION['id'] . "');";
			$sql = $this->actualizarDatos($sentencia);
			$sql->execute();
			$total = (int) $sql->fetchColumn();
		} else {
			$sentencia = "select \"SYSTEM\".ACTUALIZAR_JOB('" . $datos . "','" . $_SESSION['id'] . "');";
			$sql = $this->actualizarDatos($sentencia);
			$sql->execute();
			$total = (int) $sql->fetchColumn();
		}

		return $total;
	}

	//Funcion para guardar los datos del formulario
	public function guardarservicio()
	{

		$datosform[] = array(
			'id_servicio' => $_POST["id_servicio"],
			'id_trabajo' => $_POST["idjob_service"],
			'id_valservice' => $_POST["cmb_service"],
			'id_valappliance' => $_POST["cmb_appliance"],
			'id_valbrand' => $_POST["cmb_brand"],
			'id_valsymptom' => $_POST["cmb_symptom"],
			'model' => $this->limpiarCadena($_POST["model"]),
			'problemdetail' => $this->limpiarCadena($_POST["problemdetail"]),
			'servicefee' => $_POST["servicefee"],
			'covered' => $_POST["covered"],
		);

		$datos = json_encode($datosform);


		if ($_POST["id_servicio"] == "0") {
			$sentencia = "select \"SYSTEM\".INSERTAR_SERVICIO('" . $datos . "','" . $_SESSION['id'] . "');";
			$sql = $this->actualizarDatos($sentencia);
			$sql->execute();
			$total = (int) $sql->fetchColumn();
		} else {
			$sentencia = "select \"SYSTEM\".ACTUALIZAR_SERVICE('" . $datos . "','" . $_SESSION['id'] . "');";
			$sql = $this->actualizarDatos($sentencia);
			$sql->execute();
			$total = (int) $sql->fetchColumn();
		}

		return $total;
	}


	//Funcion para cambiar de estado al catalogo 
	public function cambiarestado($estado)
	{

		$idcat = $_POST["id_trabajo"];
		$sentencia = "select \"SYSTEM\".cambiarestado_job('" . $idcat . "','" . $estado . "','" . $_SESSION['id'] . "');";
		$sql = $this->actualizarDatos($sentencia);
		$sql->execute();

		return $sql;
	}


	//Funcion para cambiar de estado al catalogo 
	public function cambiarestadoservicio($estado)
	{

		$idcat = $_POST["id_servicio"];
		$sentencia = "select \"SYSTEM\".cambiarestado_service('" . $idcat . "','" . $estado . "','" . $_SESSION['id'] . "');";
		$sql = $this->actualizarDatos($sentencia);
		$sql->execute();

		return $sql;
	}
}

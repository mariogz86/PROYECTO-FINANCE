<div class="main-containerpermiso">

    <section class="hero-body">
	  	<div class="hero-body">
		  <?php
	
	include "./app/views/inc/btn_back.php"; 
?>
	  		<p class="has-text-centered has-text-white pb-3">
	            <!-- <i class="fas fa-satellite-dish fa-5x"></i> -->
				<i class="fas fa-user-lock fa-5x"></i>
	        </p>
		    <p class="title has-text-white">Seguridad</p>
		    <p class="subtitle has-text-white">Usted no tiene permiso para ver esta pagina..</p>
	  	</div>
	</section>
</div>
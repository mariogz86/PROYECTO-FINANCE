<?php
	 const DB_PUERTO="5432";

	 const DB_SERVER="localhost";
	 const DB_NAME="FINANCE";
	 const DB_USER="postgres";
	 const DB_PASS="2024.Gol";


	// const DB_SERVER="NANCIMI";
	//  const DB_NAME="SACN";
	// //const DB_NAME="SACNPRUEBA";
	// const DB_USER="mgomez";
	// const DB_PASS="Temporal123";


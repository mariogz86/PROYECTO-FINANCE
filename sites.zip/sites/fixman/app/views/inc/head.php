<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo APP_NAME; ?></title>
<link rel="stylesheet" href="<?php echo APP_URL; ?>app/views/css/select2.min.css">
<link rel="stylesheet" href="<?php echo APP_URL; ?>app/views/css/dataTables.dataTables.css">
<link rel="stylesheet" href="<?php echo APP_URL; ?>app/views/css/fixedColumns.dataTables.css">
<link rel="stylesheet" href="<?php echo APP_URL; ?>app/views/css/select.dataTables.css">
<link rel="stylesheet" href="<?php echo APP_URL; ?>app/views/css/buttons.dataTables.css">
<link rel="shortcut icon" href="<?php echo APP_URL; ?>app\views\img\favicon.ico"> 
<link rel="stylesheet" href="<?php echo APP_URL; ?>app/views/css/sweetalert2.min.css">
<link rel="stylesheet" href="<?php echo APP_URL; ?>app/views/css/bulma.min.css"> 
<link rel="stylesheet" href="<?php echo APP_URL; ?>app/views/css/all.css">
<link rel="stylesheet" href="<?php echo APP_URL; ?>app/views/css/estilos.css">





<script src="<?php echo APP_URL; ?>app/views/js/jquery-3.7.1.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/xlsx.full2.min.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/jquery.binarytransport.js"></script>

<script src="<?php echo APP_URL; ?>app/views/js/dataTables.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/dataTables.fixedColumns.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/fixedColumns.dataTables.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/dataTables.select.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/select.dataTables.js"></script>

<script src="<?php echo APP_URL; ?>app/views/js/dataTables.buttons.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/buttons.dataTables.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/jszip.min.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/pdfmake.min.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/vfs_fonts.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/buttons.html5.min.js"></script>
<script src="<?php echo APP_URL; ?>app/views/js/buttons.print.min.js"></script>






<link href="<?php echo APP_URL; ?>app/views/css/sb-admin-2.css" rel="stylesheet">
<script src="<?php echo APP_URL; ?>app/views/js/sweetalert2.all.min.js" ></script>

<script src="<?php echo APP_URL; ?>app/views/js/bootstrap.bundle.min.js"></script> 
<script src="<?php echo APP_URL; ?>app/views/js/jquery.easing.min.js"></script>

<script src="<?php echo APP_URL; ?>app/views/js/select2.min.js" ></script>
<div class="loadersacn" style="display: none;" ><div class="loadersacntexto">*** Espere un momento por favor ***</div></div>

	

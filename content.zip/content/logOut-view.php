<?php
    $insLogin->cerrarSesionControlador();